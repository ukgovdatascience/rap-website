globalVariables(c(".", ".mu", ".sigma", ".alpha0", ".beta0", ".alpha1", ".beta1",
                  ".number", ".cluster", ".likelihood", "data", "probability",
                  "alpha", "beta", "id"))
