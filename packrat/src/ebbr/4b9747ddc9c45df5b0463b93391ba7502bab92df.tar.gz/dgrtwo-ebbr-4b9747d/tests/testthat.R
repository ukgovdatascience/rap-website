library(testthat)
library(ebbr)

test_check("ebbr")
