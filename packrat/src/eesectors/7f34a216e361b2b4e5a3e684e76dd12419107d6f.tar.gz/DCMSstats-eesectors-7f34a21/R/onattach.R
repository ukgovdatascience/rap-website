.onAttach <- function(libname, pkgname) {
  packageStartupMessage(
"eesectors: Reproducible Analytical Pipeline (RAP) for the
Economic Estimates for DCMS Sectors Statistical First Release
(SFR). For more information visit:
https://github.com/ukgovdatascience/eesectors
"
)
}
