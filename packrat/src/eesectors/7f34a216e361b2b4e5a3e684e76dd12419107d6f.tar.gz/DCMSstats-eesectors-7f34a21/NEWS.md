# NEWS

## v0.0.0.9013

* Added `extract_DCMS_sectors()` function.
* Added `DCMS_sectors` as an in-built dataset (obviating the need to run `extract_DCMS_sectors()` except when there are changes to the DCMS sectors).
